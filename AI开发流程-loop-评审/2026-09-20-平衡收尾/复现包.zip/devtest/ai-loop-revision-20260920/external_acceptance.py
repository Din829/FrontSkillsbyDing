"""Prewritten external CLI acceptance. Kept outside the blind executor's project."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("tool", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
tool = args.tool.resolve()
args.output.mkdir(parents=True, exist_ok=False)

# Input variants share the user-visible contract, not the candidate's implementation.
cases = [
    ("existing-link", {"a.md": "[ok](target.md)", "target.md": "present"}, ["a.md"], []),
    ("missing-link", {"a.md": "[no](lost.md)"}, ["a.md"], ["lost.md"]),
    ("existing-inline", {"a.md": "`target.md`", "target.md": "present"}, ["a.md"], []),
    ("missing-inline", {"a.md": "`lost.md`"}, ["a.md"], ["lost.md"]),
    ("existing-fragment", {"a.md": "[ok](target.md#part)", "target.md": "# part"}, ["a.md"], []),
    ("missing-fragment", {"a.md": "[no](lost.md#part)"}, ["a.md"], ["lost.md"]),
    ("same-document-anchor", {"a.md": "[here](#part)\n# part"}, ["a.md"], []),
    ("commands-not-paths", {"a.md": "`python` `npm test` `exit 0`"}, ["a.md"], []),
    ("nested-link", {"docs/a.md": "[ok](../target.md)", "target.md": "present"}, ["docs/a.md"], []),
    ("nested-inline", {"a.md": "`docs/target.md`", "docs/target.md": "present"}, ["a.md"], []),
    ("nested-inline-missing", {"a.md": "`docs/lost.md`"}, ["a.md"], ["docs/lost.md"]),
    ("all-documents", {"a.md": "[no](first.md)", "b.md": "`second.md`"}, ["a.md", "b.md"], ["first.md", "second.md"]),
    ("unicode", {"a.md": "`说明.md`", "说明.md": "present"}, ["a.md"], []),
    ("unicode-missing", {"a.md": "`缺失.md`"}, ["a.md"], ["缺失.md"]),
]

results = []
for name, files, inputs, missing in cases:
    work = args.output / name
    work.mkdir()
    for path, content in files.items():
        destination = work / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content, encoding="utf-8")
    command = [sys.executable, str(tool), *inputs]
    cp = subprocess.run(command, cwd=work, capture_output=True, text=True, encoding="utf-8",
                        env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    output = cp.stdout + cp.stderr
    passed = (cp.returncode != 0 if missing else cp.returncode == 0)
    passed = passed and all(path in output for path in missing) and "Traceback" not in output
    results.append({"case": name, "files": files, "cwd": str(work), "argv": command,
                    "expected_missing": missing, "exit_code": cp.returncode,
                    "stdout": cp.stdout, "stderr": cp.stderr, "passed": passed})
    print(f"{name}: {'ACCEPT' if passed else 'REJECT'} (exit={cp.returncode})")

record = {"tool": str(tool), "tool_sha256": hashlib.sha256(tool.read_bytes()).hexdigest(),
          "cases": results, "accepted": sum(r["passed"] for r in results), "total": len(results)}
(args.output / "results.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
sys.exit(0 if all(r["passed"] for r in results) else 1)
