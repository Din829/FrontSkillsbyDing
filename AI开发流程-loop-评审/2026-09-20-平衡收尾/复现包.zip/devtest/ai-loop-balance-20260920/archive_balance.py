"""Finalize local evidence and reviewable changes; no git mutation or publication."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

BASE = Path(__file__).resolve().parent
WS = BASE.parents[1]
REPO = WS / "参考设计思想"
SOURCE = REPO / "AI开发流程-loop"
REPORT = REPO / "AI开发流程-loop-评审/2026-09-20-平衡收尾"
ignored = {"__pycache__", ".mypy_cache", ".pytest_cache", "node_modules", ".git"}
diff = []
changes = []
for old in sorted((BASE / "before").rglob("*.md")):
    relative = old.relative_to(BASE / "before")
    current = SOURCE / relative
    if old.read_bytes() != current.read_bytes():
        changes.append(str(relative))
        diff.extend(difflib.unified_diff(old.read_text(encoding="utf-8").splitlines(True),
                                        current.read_text(encoding="utf-8").splitlines(True),
                                        fromfile="before/" + str(relative), tofile="after/" + str(relative)))
(BASE / "balance.diff").write_text("".join(diff), encoding="utf-8")
assert len(changes) == 6
assert (SOURCE / "scripts/README.md").read_bytes() == (BASE / "before/scripts/README.md").read_bytes()
assert (WS / "devtest/frontend-skills-test/check_links.py").read_bytes() == (WS / "devtest/ai-loop-revision-20260920/trial-before/check_links.py").read_bytes()

shutil.copytree(BASE, REPORT / "evidence", ignore=shutil.ignore_patterns(*ignored))
shutil.copytree(SOURCE, REPORT / "after")
with zipfile.ZipFile(REPORT / "复现包.zip", "x", zipfile.ZIP_DEFLATED) as archive:
    for root in [BASE, SOURCE]:
        for p in sorted(root.rglob("*")):
            if p.is_file() and not ignored.intersection(p.parts):
                archive.write(p, p.relative_to(WS))
    checker = WS / "devtest/ai-loop-revision-20260920/external_acceptance.py"
    archive.write(checker, checker.relative_to(WS))
with zipfile.ZipFile(REPORT / "复现包.zip") as archive:
    assert archive.testzip() is None

head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True, check=True).stdout.strip()
manifest = {str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE.rglob("*") if p.is_file()}
summary = {"git_head": head, "commit_created": False, "pushed": False, "pr_created": False,
           "changed_this_stage": changes, "final_rule_hashes": manifest,
           "original_link_tool_unchanged": True, "scripts_readme_unchanged": True,
           "dedicated_reviewai_available": False, "independent_ai_review_file": "evidence/final-review.md",
           "archive_sha256": hashlib.sha256((REPORT / "复现包.zip").read_bytes()).hexdigest()}
(REPORT / "交付核验.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

links = []
for doc in REPORT.glob("*.md"):
    for target in re.findall(r"\]\(([^)]+)\)", doc.read_text(encoding="utf-8")):
        if target.startswith(("http://", "https://")):
            continue
        assert (doc.parent / target.split("#")[0]).resolve().exists(), (doc.name, target)
        links.append({"document": doc.name, "target": target})
summary["checked_local_links"] = links
(REPORT / "交付核验.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"report": str(REPORT), "changed": changes, "local_links_checked": len(links),
                  "zip_bytes": (REPORT / "复现包.zip").stat().st_size}, ensure_ascii=False))
