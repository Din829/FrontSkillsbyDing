import importlib.util
from pathlib import Path
import unittest


DATA_PATH = Path(__file__).parent / '成果物' / 'testdata' / 'cases.py'
spec = importlib.util.spec_from_file_location('amount_cases', DATA_PATH)
cases = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cases)


class AmountTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if 'parse' not in cls.__dict__:
            from amounts import parse_cents
            cls.parse = staticmethod(parse_cents)

    def test_examples_and_integer_result(self):
        for text, expected in cases.VALID:
            with self.subTest(text=text):
                result = self.parse(text)
                self.assertIs(type(result), int)
                self.assertEqual(result, expected)

    def test_invalid_syntax(self):
        for text in cases.INVALID:
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    self.parse(text)

    def test_non_ascii_digits(self):
        for text in cases.NON_ASCII:
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    self.parse(text)

    def test_large_integer_precision(self):
        for text, expected in cases.LARGE:
            with self.subTest(length=len(text), negative=text.startswith('-')):
                self.assertTrue(self.parse(text) == expected, 'large integer cents mismatch')

    def test_all_cent_fractions(self):
        for cents in range(100):
            for sign in (1, -1):
                text = ('-' if sign < 0 else '+') + f'17.{cents:02}'
                with self.subTest(text=text):
                    self.assertEqual(self.parse(text), sign * (1700 + cents))


if __name__ == '__main__':
    unittest.main()
