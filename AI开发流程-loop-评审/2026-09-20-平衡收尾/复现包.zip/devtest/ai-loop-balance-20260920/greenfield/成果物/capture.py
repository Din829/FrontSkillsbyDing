from pathlib import Path
import subprocess
import sys

log = Path(sys.argv[1])
command = [sys.executable, *sys.argv[2:]]
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
with log.open('xb') as output:
    output.write(('command=' + repr(command) + '\n').encode('utf-8'))
    output.write(result.stdout)
    output.write(f'\nexit_code={result.returncode}\n'.encode())
print(f'{log}: exit_code={result.returncode}')
sys.exit(result.returncode)
