from pathlib import Path
import re
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_amounts import AmountTests, cases

known = dict(cases.VALID + cases.LARGE)
for cents in range(100):
    for sign in (1, -1):
        known[('-' if sign < 0 else '+') + f'17.{cents:02}'] = sign * (1700 + cents)


def known_good(text):
    if text in known:
        return known[text]
    raise ValueError('known invalid sample')


def floats(text):
    return int(float(text) * 100)


def unicode_digits(text):
    trimmed = text.strip()
    if re.fullmatch(r'[+-]?\d+(?:\.\d{1,2})?', trimmed):
        if any(ord(char) > 127 for char in trimmed):
            return 0
    return known_good(text)


def truncate(text):
    if text.strip() in ('1.234', '-0.001'):
        return 123 if text.strip() == '1.234' else 0
    return known_good(text)


if __name__ == '__main__':
    mismatches = 0
    for name, parser, should_pass in [
        ('known_good_table', known_good, True),
        ('wrong_zero', lambda text: 0, False),
        ('wrong_float', floats, False),
        ('wrong_unicode', unicode_digits, False),
        ('wrong_truncation', truncate, False),
    ]:
        print(f'=== {name}; expected_pass={should_pass} ===', flush=True)
        cls = type(name, (AmountTests,), {'parse': staticmethod(parser)})
        result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
        matches = result.testsRun == 5 and result.wasSuccessful() == should_pass
        mismatches += not matches
        print(f'calibration_match={matches}; tests={result.testsRun}; failures={len(result.failures)}; errors={len(result.errors)}', flush=True)
    print(f'CALIBRATION mismatches={mismatches}', flush=True)
    sys.exit(bool(mismatches))
