from decimal import Decimal, localcontext
from pathlib import Path
import random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from amounts import parse_cents

randomizer = random.Random(20260920)
with localcontext() as context:
    context.prec = 6000
    for _ in range(2000):
        length = randomizer.randrange(1, 150)
        whole = ''.join(str(randomizer.randrange(10)) for _ in range(length))
        places = randomizer.randrange(3)
        fraction = ''.join(str(randomizer.randrange(10)) for _ in range(places))
        text = randomizer.choice(['', '+', '-']) + whole + ('.' + fraction if places else '')
        expected = int(Decimal(text) * 100)
        assert parse_cents('\t' + text + '\n') == expected
    huge = '7' * 5000 + '.13'
    assert parse_cents(huge) == int(Decimal(huge) * 100)
for text in ['1\r.2', '1\u00a02', '１.00', '1.000', '1\n+2', '1e309']:
    try:
        parse_cents(text)
    except ValueError:
        continue
    raise AssertionError(f'Accepted invalid text: {text!r}')
print('Decimal crosscheck: 2000 generated valid amounts + 5000-digit amount matched')
print('Additional invalid boundary checks: 6 rejected with ValueError')
