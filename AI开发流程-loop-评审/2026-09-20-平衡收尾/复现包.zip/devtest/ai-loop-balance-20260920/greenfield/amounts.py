"""Parse an ASCII decimal amount into exact integer cents."""

import re


def parse_cents(text: str) -> int:
    """Return cents, or raise ValueError for invalid amount syntax."""
    match = re.fullmatch(r'([+-]?)([0-9]+)(?:\.([0-9]{1,2}))?', text.strip())
    if match is None:
        raise ValueError('Invalid amount')
    sign, whole, fraction = match.groups()
    digits = whole + (fraction or '').ljust(2, '0')
    cents = 0
    # Small chunks avoid Python's limit on decimal-string conversion.
    for offset in range(0, len(digits), 9):
        chunk = digits[offset:offset + 9]
        cents = cents * 10 ** len(chunk) + int(chunk)
    return -cents if sign == '-' else cents
