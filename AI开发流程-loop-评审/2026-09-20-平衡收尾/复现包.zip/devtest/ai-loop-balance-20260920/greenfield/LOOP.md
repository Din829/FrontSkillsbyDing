# 目标循环账本

## 目标
任务 2：实现 README 已授权的 parse_cents(text: str) -> int。敏捷档；去首尾空白，只接受 ASCII 数字、可选正负号、小数点后 1–2 位；返回精确整数分；非法格式 ValueError。不做 IO、网络、UI、货币转换或非 str 契约外处理。

## 验证命令清单
| 命令 | 判定标准 |
|---|---|
| `python -m unittest -v test_amounts` | 5 个方法全部执行，0 failures/errors |
| `python 成果物/crosscheck.py` | 独立 Decimal 对照及额外边界断言通过 |
| `python -m mypy --strict --follow-imports=skip amounts.py` | exit 0，生产模块无类型错误 |

## 配置
轮次上限：10；连续 2 轮无有效进展停止。
成果物：amounts.py、真实测试输出、独立对照、验收对照报告。
前置校准：成果物/loops/LOOP-1-20260920-01.md，已完成。

## 状态
✅ 当前：Round 1；2026-09-20。机械验收完成，最终人工验收待用户。
现场：greenfield 当前目录；模块与测试新增完毕；不读取外部任务，无提交。

## 基线（Round 0，进 gate 前必填）
前置出口同一现场真实业务检查：成果物/missing-module-raw.log。
```text
ModuleNotFoundError: No module named 'amounts'
Ran 0 tests in 0.001s
FAILED (errors=1)
exit_code=5
```
这是已校准测试检查缺失产物，不是环境损坏，也不是业务正确。

## Round 1：整数分解析（2026-09-20）
### 改了什么
新增 amounts.py：fullmatch + ASCII 数字范围 + 短块整数累积，避免浮点误差和单次 int 转换的位数上限。新增成果物/crosscheck.py，用另一算法 Decimal 对照。测试断言与期望未更改。
### 验证输出
完整命令及原文见成果物/business-final.log、crosscheck.log、typecheck.log。原文关键段：
```text
test_all_cent_fractions (test_amounts.AmountTests.test_all_cent_fractions) ... ok
test_examples_and_integer_result (test_amounts.AmountTests.test_examples_and_integer_result) ... ok
test_invalid_syntax (test_amounts.AmountTests.test_invalid_syntax) ... ok
test_large_integer_precision (test_amounts.AmountTests.test_large_integer_precision) ... ok
test_non_ascii_digits (test_amounts.AmountTests.test_non_ascii_digits) ... ok

----------------------------------------------------------------------
Ran 5 tests in 0.004s

OK

exit_code=0
```
```text
Decimal crosscheck: 2000 generated valid amounts + 5000-digit amount matched
Additional invalid boundary checks: 6 rejected with ValueError

exit_code=0
```
```text
Success: no issues found in 1 source file

exit_code=0
```
### 错误指纹
ModuleNotFoundError amounts → 无失败；进展：模块已存在，5 个方法的 257 个输入检查通过。独立对照和生产模块严格类型检查均通过。
### 下一轮计划
进收尾，交付用户验收。

## 收尾核验
- 独立对照：Decimal 算法与实际输出核对，不复用生产正则或整数累积；不是独立 agent 评审。
- diff 回看：`git diff --no-index -- NUL amounts.py` 实际查看新增 18 行；回读测试与数据。全部为本任务功能和证据，无无关重构。
- 影响检查：N/A，纯新增独立函数，当前项目原来仅 README，没有调用方；未跨越授权目录查下游。
- 基线 → 终态：模块缺失、5 个方法尚不能执行 → 257 输入检查全通过，业务 1 轮完成。
- 类型检查：本项目纯 Python，无 package.json，不运行不适用的 npm 命令；现场确认 mypy 可导入后使用 Python 严格类型检查。
- 教训回写：N/A，没有二次踩坑。
- 证据绑定 SHA256：amounts.py `2CE0EA1F6FF25784C2179DE613C012ABC562D2C2F7E4D471217B981D734158D8`；test_amounts.py `CAAFD6FCA239E48C2A2690EF34B1B7A9A4E66B2D1C501C0284E7A63EEF1BB777`；cases.py `483946B7140D893E18FC9A43760D32259C8FF5CFFE6F21A52E3F1FE17F9151D5`；crosscheck.py `8972F07C1FA29BCA7D01A6E87EF6D64432227C757FDA1AA76EE936CED571AB87`。
- 交付前 claim-check：以下报告分别标实测、读到的和未验证；未把自评说成独立评审。

## 刹车记录（如触发）
未触发。
