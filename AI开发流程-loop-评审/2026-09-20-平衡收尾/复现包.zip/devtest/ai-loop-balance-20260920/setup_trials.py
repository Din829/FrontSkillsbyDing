"""Create three isolated, bounded flow trials with actual baseline output."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
WS = BASE.parents[1]
OLD = WS / "devtest/ai-loop-revision-20260920/trial"
resume = BASE / "resume"
shutil.copytree(OLD, resume, ignore=shutil.ignore_patterns("__pycache__"))
original = (resume / "check_links.py").read_text(encoding="utf-8")
assert original.count("sys.exit(1 if bad else 0)") == 1
(resume / "check_links.py").write_text(original.replace("sys.exit(1 if bad else 0)", "sys.exit(0)"), encoding="utf-8")
(resume / "HANDOFF.md").write_text("# 接续任务\n\n上次记录和成果物保留在本目录。继续原 README 的验收与交付，按当前现场判断；技术选择与敏捷档仍已授权。只操作本目录与读取流程入口，不读父级实验、旧评审或其它任务。不得提交、联网或启动子代理/开发服务器。\n", encoding="utf-8")

for name in ["greenfield", "batch"]:
    (BASE / name).mkdir()
facts = {"resume": {"source_before_sha256": hashlib.sha256(original.encode()).hexdigest(),
                     "current_source_sha256": hashlib.sha256((resume / "check_links.py").read_bytes()).hexdigest(),
                     "ledger_sha256": hashlib.sha256((resume / "LOOP.md").read_bytes()).hexdigest()},
         "greenfield": "business module and tests absent at setup"}
(BASE / "setup-facts.json").write_text(json.dumps(facts, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(facts, ensure_ascii=False))
