import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent
DATA = ROOT / '成果物' / 'testdata'
SCRIPT = Path(os.environ.get('CHECK_LINKS_SCRIPT', ROOT / 'check_links.py')).resolve()
CASES = json.loads((DATA / 'cases.json').read_text(encoding='utf-8'))


class LinkCLITests(unittest.TestCase):
    def check_case(self, case):
        directory = DATA / 'cases' / case['id']
        for name, content in case['files'].items():
            path = directory / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding='utf-8')
        command = [sys.executable, str(SCRIPT), *(str(directory / name) for name in case['docs'])]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                encoding='utf-8', env={**os.environ, 'PYTHONUTF8': '1'})
        with (ROOT / '成果物' / 'evidence' / 'cli-runs.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({'case': case['id'], 'command': command, 'cwd': str(ROOT),
                                     'exit_code': result.returncode, 'stdout': result.stdout,
                                     'stderr': result.stderr}, ensure_ascii=False) + '\n')
        expected = {f'  MISSING  {directory / doc} -> {ref}' for doc, ref in case['missing']}
        lines = result.stdout.splitlines()
        self.assertEqual(set(lines[:-1]), expected, result.stdout)
        self.assertEqual(lines[-1:], [f'done, problems={len(expected)}'])
        self.assertEqual(result.stderr, '')
        self.assertEqual(result.returncode, int(bool(expected)), result.stdout)


def make_test(case):
    def test(self):
        self.check_case(case)
    return test


for case in CASES:
    setattr(LinkCLITests, f'test_{case["id"]}', make_test(case))


if __name__ == '__main__':
    unittest.main()
