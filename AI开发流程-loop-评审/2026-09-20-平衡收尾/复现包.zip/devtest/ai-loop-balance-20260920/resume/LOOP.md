# 目标循环账本

## 目标
修复本地 Markdown 引用漏报和失败退出行为。意图来源：README.md；范围与敏捷档已确认，技术命令和补测试已授权。

验收条件：普通相对链接、行内裸 .md 与子目录路径均检查；相对源文档解析；片段只检查文件、同页片段忽略；已有文件通过、缺文件指出引用且非零退出；多个文档全部检查；普通命令词不误报；保留 HTTP 逻辑且测试不联网。空格、括号路径和完整 Markdown 解析不在范围。

路由：已有代码的单发目标 → 实现 loop B；缺少验证器 → 先按 C 构建并校准。当前任务先建验证器，随后修业务代码；单项任务不补完整方案。

## 验证命令清单
| 命令 | 判定标准 |
|---|---|
| `python -m unittest discover -v` | 建设基线允许 0 测试，但不算业务通过；建成后必须执行所有案例且失败数 0 |
| `python -m unittest discover -v`（CHECK_LINKS_SCRIPT 指向已知正确的本地参考检查器） | 全部实际 CLI 案例通过，用于绿色校准 |
| `python -m unittest discover -v`（指向原始检查器） | 必须识别已知漏报/错误退出，用于红色校准与业务基线 |
| `python -m py_compile check_links.py test_check_links.py` | exit 0，Python 语法检查；不是完整静态类型检查 |
| `python check_links.py <独立混合输入...>` | 缺文件逐项输出、最后问题数正确、exit 1；另一组全有效输入 exit 0 |

选择依据：项目只有 Python 脚本和 README，无 package.json/npm type-check；使用 Python 标准库 unittest 和真实子进程，不 mock、不联网。

## 配置
轮次上限：10 ｜ 停滞阈值：连续 2 轮无有效进展。
成果物：本账本、测试代码、成果物/testdata/ 下规范/数据/期望、成果物/evidence/ 下原始 stdout/stderr/exit code、最终交付报告。
校准：已知错误为原脚本（裸文件/片段漏报、总是 exit 0）；已知正确为独立本地参考检查器，对同一批真实文件做文件存在性判断；两者均用真实 Python 运行器。

## 状态
✅ 当前：Round 3 技术交付完成，待最终人工验收；最后更新：2026-09-20。旧 Round 2 状态仅代表旧版本。
现场：当前为 resume 目录；原 trial 描述属历史记录，完整原账本已存 evidence/resume-before-LOOP.md。当前代码摘要与续跑结果见文末；未提交、不启动开发服务器、不读取项目外旧评审/实验/验收脚本。

## 基线（Round 0，进 gate 前必填）
命令：`python -m unittest discover -v`

stdout 原文：
```text

```
stderr 原文：
```text


----------------------------------------------------------------------

Ran 0 tests in 0.000s



NO TESTS RAN


```
退出码：5

建设基线 exit 5 / NO TESTS RAN，不是业务测试失败。

## Round 1：构建与校准验证器（2026-09-20）
### 改了什么
新增 test_check_links.py、13 组测试三件套和独立本地参考检查器；原始业务脚本尚未修改，已存原件。测试期望直接来自 README 与文件存在状态；无旧断言被放宽。
### 验证输出
命令：`python -m unittest discover -v`

stdout 原文：
```text

```
stderr 原文：
```text
test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths) ... ok

test_document_relative (test_check_links.LinkCLITests.test_document_relative) ... ok

test_existing_fragments (test_check_links.LinkCLITests.test_existing_fragments) ... ok

test_existing_paths (test_check_links.LinkCLITests.test_existing_paths) ... ok

test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link) ... ok

test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments) ... ok

test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare) ... ok

test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child) ... ok

test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown) ... ok

test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents) ... ok

test_ordinary_commands (test_check_links.LinkCLITests.test_ordinary_commands) ... ok

test_same_page (test_check_links.LinkCLITests.test_same_page) ... ok

test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths) ... ok



----------------------------------------------------------------------

Ran 13 tests in 0.766s



OK


```
退出码：0

命令：`python -m unittest discover -v`

stdout 原文：
```text

```
stderr 原文：
```text
test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths) ... FAIL

test_document_relative (test_check_links.LinkCLITests.test_document_relative) ... ok

test_existing_fragments (test_check_links.LinkCLITests.test_existing_fragments) ... ok

test_existing_paths (test_check_links.LinkCLITests.test_existing_paths) ... ok

test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link) ... FAIL

test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments) ... FAIL

test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare) ... FAIL

test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child) ... FAIL

test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown) ... FAIL

test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents) ... FAIL

test_ordinary_commands (test_check_links.LinkCLITests.test_ordinary_commands) ... ok

test_same_page (test_check_links.LinkCLITests.test_same_page) ... ok

test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths) ... FAIL



======================================================================

FAIL: test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 30, in check_case

    self.assertEqual(set(lines[:-1]), expected, result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: Items in the second set but not the first:

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\command_prefix_paths\\doc.md -> scripts/search-guide.md'

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\command_prefix_paths\\doc.md -> node.md'

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\command_prefix_paths\\doc.md -> python.md'

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\command_prefix_paths\\doc.md -> npm.md' : done, problems=0





======================================================================

FAIL: test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\成果物\testdata\cases\extensionless_link\doc.md -> NOTICE

done, problems=1





======================================================================

FAIL: test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 30, in check_case

    self.assertEqual(set(lines[:-1]), expected, result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: Items in the second set but not the first:

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\missing_fragments\\doc.md -> other.md#part'

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\missing_fragments\\doc.md -> sub/absent.txt#part'

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\missing_fragments\\doc.md -> lost.md#part' : done, problems=0





======================================================================

FAIL: test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 30, in check_case

    self.assertEqual(set(lines[:-1]), expected, result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: Items in the second set but not the first:

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\missing_inline_bare\\doc.md -> absent.md' : done, problems=0





======================================================================

FAIL: test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\成果物\testdata\cases\missing_inline_child\doc.md -> sub/absent.txt

done, problems=1





======================================================================

FAIL: test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\成果物\testdata\cases\missing_markdown\doc.md -> gone.md

done, problems=1





======================================================================

FAIL: test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 30, in check_case

    self.assertEqual(set(lines[:-1]), expected, result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: Items in the second set but not the first:

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\multiple_documents\\last\\doc.md -> b.md' :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\成果物\testdata\cases\multiple_documents\first\doc.md -> a.md

done, problems=1





======================================================================

FAIL: test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\test_check_links.py", line 30, in check_case

    self.assertEqual(set(lines[:-1]), expected, result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: Items in the second set but not the first:

'  MISSING  C:\\Users\\q9951\\Desktop\\AgenticWorkflow\\devtest\\ai-loop-revision-20260920\\trial\\成果物\\testdata\\cases\\unicode_paths\\文档\\入口.md -> 缺少.md' :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-revision-20260920\trial\成果物\testdata\cases\unicode_paths\文档\入口.md -> 子目录/文件.md

done, problems=1





----------------------------------------------------------------------

Ran 13 tests in 1.219s



FAILED (failures=8)


```
退出码：1

### 错误指纹
原脚本失败：command_prefix_paths、extensionless_link、missing_fragments、missing_inline_bare、missing_inline_child、missing_markdown、multiple_documents、unicode_paths。
进展证据：同一套 13 案例在独立参考检查器上 0 失败，在原脚本上 8 失败。缺文件负例在正确实现上测试通过；红灯来自原脚本行为，不是启动错误。每个子进程完整命令与输出见 evidence/cli-runs.jsonl。
记录插曲：首次用 PowerShell 管道传入中文 Python 代码时，路径被编码为 ???，触发 OSError 22，账本未修改；明确设置 OutputEncoding UTF-8 后写入成功。这不是业务失败，不计业务 loop 轮数。
### 下一轮计划
验证器红绿校准与业务基线已完成；保持这 13 个测试不变，修原脚本路径提取与最终退出码。

## Round 2：修本地引用与退出行为（2026-09-20）
### 改了什么
check_links.py：提取裸 .md/子目录行内路径和带片段 Markdown 链接；去掉命令名前缀过滤，明确排除 HTTP URL；结束时按总问题数返回 0/1。删除与真实代码不符的备用根目录注释。测试代码与既有断言不变。
### 验证输出

命令：`python -m unittest discover -v`

stdout 原文：
```text

```
stderr 原文：
```text
test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths) ... ok

test_document_relative (test_check_links.LinkCLITests.test_document_relative) ... ok

test_existing_fragments (test_check_links.LinkCLITests.test_existing_fragments) ... ok

test_existing_paths (test_check_links.LinkCLITests.test_existing_paths) ... ok

test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link) ... ok

test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments) ... ok

test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare) ... ok

test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child) ... ok

test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown) ... ok

test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents) ... ok

test_ordinary_commands (test_check_links.LinkCLITests.test_ordinary_commands) ... ok

test_same_page (test_check_links.LinkCLITests.test_same_page) ... ok

test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths) ... ok



----------------------------------------------------------------------

Ran 13 tests in 1.149s



OK


```
退出码：0

命令：`python -m py_compile check_links.py test_check_links.py`

stdout 原文：
```text

```
stderr 原文：
```text

```
退出码：0

命令：`python check_links.py 成果物/testdata/manual-negative/first.md 成果物/testdata/manual-negative/sub/last.md`

stdout 原文：
```text
  MISSING  成果物/testdata/manual-negative/first.md -> node.md#section

  MISSING  成果物/testdata/manual-negative/sub/last.md -> ../python-guide.md#part

  MISSING  成果物/testdata/manual-negative/sub/last.md -> deeper/a+b.md

done, problems=3


```
stderr 原文：
```text

```
退出码：1

命令：`python check_links.py 成果物/testdata/manual-positive/first.md 成果物/testdata/manual-positive/sub/last.md`

stdout 原文：
```text
done, problems=0


```
stderr 原文：
```text

```
退出码：0

命令：`python 成果物/evidence/review_sources.py`

stdout 原文：
```text
HTTP block text comparison: identical (not a network test).

e1faaebb9eaeb3bafdf13cb33ab8c2e3825aafde66a7b6b37e034f4d49f44ea4 README.md

259007f15089ddb0a4a9649fbf4a99a4244076a68e7a3d11206da246f59ac915 check_links.py

cf75bb6abbe2c3d25a03724f88d13104f2c819e020cef8224165451d396de4e0 test_check_links.py

5991438e7e1752a24c6a14d2c3e13b9e94284ff39b4c80d3bfeb55c1d27c667b 成果物/evidence/original_check_links.py

d02935b409642d0712973ec4509172c5beabaf182b03d38abcc671715713c052 成果物/testdata/cases.json

--- original_check_links.py

+++ check_links.py

@@ -11,16 +11,18 @@

 for mf in md_files:

     base = os.path.dirname(os.path.abspath(mf))

     text = open(mf, encoding='utf-8').read()

-    # 相对路径：`xxx/yyy.md` 或 [..](xxx/yyy.md)，排除 http 与含空格的

-    rels = set(re.findall(r'`((?:[\w一-鿿.-]+/)+[\w一-鿿.-]*)`', text))

-    rels |= set(re.findall(r'\]\(((?!http)[^)\s#]+)\)', text))

+    # 行内代码只识别裸 .md 或含目录的路径；Markdown 链接可省扩展名。

+    rels = {

+        r for r in re.findall(r'`([^`\s()]+)`', text)

+        if '/' in r.split('#')[0] or r.split('#')[0].endswith('.md')

+    }

+    rels |= set(re.findall(r'\]\(([^()\s]+)\)', text))

     for r in sorted(rels):

         r2 = r.split('#')[0]

-        if not r2 or r2.startswith(('--', 'python', 'npm', 'node', 'scripts/search')):

+        if not r2 or r2.startswith(('http://', 'https://')):

             continue

         p = os.path.normpath(os.path.join(base, r2))

         if not os.path.exists(p):

-            # 也试从 参考资料/ 根解析（pro 里写的是相对自己目录的路径）

             print(f"  MISSING  {mf} -> {r}")

             bad += 1

     urls = set(re.findall(r'https?://[^\s)>\]`"]+', text))

@@ -34,3 +36,4 @@

         except Exception as e:

             print(f"  HTTP ERR  {mf} -> {u}  ({str(e)[:60]})"); bad += 1

 print(f"done, problems={bad}")

+sys.exit(1 if bad else 0)




```
stderr 原文：
```text

```
退出码：0

命令：`rg -n check_links README.md check_links.py test_check_links.py`

stdout 原文：
```text
check_links.py:5:用法：python check_links.py <md 文件...>
README.md:3:`python check_links.py <md 文件...>` 检查 Markdown 文件中的引用。现有代码还没有合适的自动化测试。
test_check_links.py:10:SCRIPT = Path(os.environ.get('CHECK_LINKS_SCRIPT', ROOT / 'check_links.py')).resolve()

```
stderr 原文：
```text

```
退出码：0

### 错误指纹
空；上一轮 8 个失败案例本轮全部通过。
进展证据：相同 13 项从 8 失败变为 0 失败；独立两文档混合输入查出 3 个缺失并 exit 1，补齐文件后同样引用 exit 0。manual-negative 的非零退出是预期业务拒绝，不是验收失败。
### 下一轮计划
进收尾；无待修业务失败。

## 收尾核验
- 独立对照：使用未参与 13 项测试的新混合文档，含中文目录、../、片段、命令和 a+b.md 文件名；实测 3 个缺失全部报告，补齐后通过。数据及两组原文均保留。
- diff 回看：仅本地路径提取、错误前缀过滤和最终退出行为变化；删除一处误导注释直接关联路径解析，不做无关重构。13 个测试未放宽、未跳过；没有 mock。
- 影响检查：项目仅 README 是原有调用说明，新测试按 CLI 调用；项目内搜索结果已留。缺文件最终 exit 1 是需求明确的契约变化。HTTP 请求代码段逐字相同；未联网，不声称 HTTP 测试通过。未查看或修改项目外调用方。
- 基线 → 终态：建设基线 0 测试/exit 5 → 已校准业务基线 13 项中 8 失败 → 13 项 0 失败；共 2 轮（建设 1，业务修复 1）。
- 验收条件逐条核销：成果物/交付报告.md 的验收对照表；每条均指向本轮证据。
- 类型检查：N/A，项目不存在 npm/type-check 配置；实际执行 Python 语法编译且 exit 0，不冒充类型检查。
- 教训回写：N/A，没有同类业务问题第二次发生；一次管道编码插曲已记在 Round 1。
- claim-check：实测结论有原始输出；HTTP 保持不变是源码对照；网络与范围外 Markdown 语法标为未验证。
- 证据归档：本任务仍为当前单项任务，LOOP.md 保留根目录；下一任务启动前再移入成果物/loops/，避免无故移动证据链接。
- 最终版本：check_links.py SHA-256 259007f15089ddb0a4a9649fbf4a99a4244076a68e7a3d11206da246f59ac915；其他输入摘要见 source-review.json。所有新增文件与修改均未提交。


## 刹车记录（如触发）
尚未触发。

## 续跑现场核对（2026-09-20）
当前工作目录：C:/Users/q9951/Desktop/AgenticWorkflow/devtest/ai-loop-balance-20260920/resume。
路由：已有账本 → 实现 loop 续跑；README 意图、敏捷档和技术选择授权未变。
当前 check_links.py SHA-256 为 1fef8b66a63a828a54d651509f7fe84172e2ba6e1611ad716701008ad055878e，与旧交付 259007... 不同；末行是 sys.exit(0)。README、test_check_links.py、cases.json 摘要与旧证据相同，原裁判和校准记录继续适用，不重复建设验证器。源码现状见 evidence/resume-source-before.json，完整修改前代码和账本见 evidence/resume-before-*。
已重跑相关测试：8 项失败，均正确报告缺文件但返回 0；这是业务回归，不是工具启动失败。旧报告不用于当前验收。
契约沿用：恢复 README 所需缺文件非零退出；裁判仍为原 13 项 unittest、语法编译、独立正反 CLI；总轮次上限 10、连续 2 轮无有效进展停止；新证据均以 resume- 命名，不覆盖旧文件。
最小规则解释：本次明确授权自主接续并实现，视为阶段切换授权，仍分别声明分析、细化、执行，不重复求批准。项目只有 Python、无 npm 类型检查配置，继续做语法检查并明确不等于类型检查。入口要求最终人工验收，本次只完成技术交付，不代替用户验收。未修改流程文件。

### 续跑基线原文

命令：`python -m unittest discover -v`
退出码：1
stdout 原文：
```text

```

stderr 原文：
```text
test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths) ... FAIL

test_document_relative (test_check_links.LinkCLITests.test_document_relative) ... ok

test_existing_fragments (test_check_links.LinkCLITests.test_existing_fragments) ... ok

test_existing_paths (test_check_links.LinkCLITests.test_existing_paths) ... ok

test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link) ... FAIL

test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments) ... FAIL

test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare) ... FAIL

test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child) ... FAIL

test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown) ... FAIL

test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents) ... FAIL

test_ordinary_commands (test_check_links.LinkCLITests.test_ordinary_commands) ... ok

test_same_page (test_check_links.LinkCLITests.test_same_page) ... ok

test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths) ... FAIL



======================================================================

FAIL: test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\command_prefix_paths\doc.md -> node.md

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\command_prefix_paths\doc.md -> npm.md

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\command_prefix_paths\doc.md -> python.md

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\command_prefix_paths\doc.md -> scripts/search-guide.md

done, problems=4





======================================================================

FAIL: test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\extensionless_link\doc.md -> NOTICE

done, problems=1





======================================================================

FAIL: test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_fragments\doc.md -> lost.md#part

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_fragments\doc.md -> other.md#part

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_fragments\doc.md -> sub/absent.txt#part

done, problems=3





======================================================================

FAIL: test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_inline_bare\doc.md -> absent.md

done, problems=1





======================================================================

FAIL: test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_inline_child\doc.md -> sub/absent.txt

done, problems=1





======================================================================

FAIL: test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\missing_markdown\doc.md -> gone.md

done, problems=1





======================================================================

FAIL: test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\multiple_documents\first\doc.md -> a.md

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\multiple_documents\last\doc.md -> b.md

done, problems=2





======================================================================

FAIL: test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths)

----------------------------------------------------------------------

Traceback (most recent call last):

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 38, in test

    self.check_case(case)

    ~~~~~~~~~~~~~~~^^^^^^

  File "C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\test_check_links.py", line 33, in check_case

    self.assertEqual(result.returncode, int(bool(expected)), result.stdout)

    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

AssertionError: 0 != 1 :   MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\unicode_paths\文档\入口.md -> 子目录/文件.md

  MISSING  C:\Users\q9951\Desktop\AgenticWorkflow\devtest\ai-loop-balance-20260920\resume\成果物\testdata\cases\unicode_paths\文档\入口.md -> 缺少.md

done, problems=2





----------------------------------------------------------------------

Ran 13 tests in 1.159s



FAILED (failures=8)


```

## Round 3：恢复续跑现场的失败退出（2026-09-20）
### 改了什么
check_links.py 末行 sys.exit(0) 恢复为 sys.exit(1 if bad else 0)。不改测试、断言、HTTP 或引用解析；补丁触及末行时该行换行由 CRLF 变 LF，其余源码保持。新增续跑证据与报告；旧证据不覆盖，cli-runs.jsonl 只追加。再次出现缺文件 exit 0，项目 CLAUDE.md 新增一行续跑核对提示。
### 验证输出
以下由原始 JSON 直接读取粘贴；完整命令、cwd、stdout/stderr、退出码可在同名证据文件复核。依赖搜索完整原文单独保存在 resume-dependent-search.json，结果涉及 README/测试调用和账本记录。

证据：成果物/evidence/resume-implementation-tests.json
命令：`python -m unittest discover -v`
退出码：0

stdout 原文：
```text

```

stderr 原文：
```text
test_command_prefix_paths (test_check_links.LinkCLITests.test_command_prefix_paths) ... ok
test_document_relative (test_check_links.LinkCLITests.test_document_relative) ... ok
test_existing_fragments (test_check_links.LinkCLITests.test_existing_fragments) ... ok
test_existing_paths (test_check_links.LinkCLITests.test_existing_paths) ... ok
test_extensionless_link (test_check_links.LinkCLITests.test_extensionless_link) ... ok
test_missing_fragments (test_check_links.LinkCLITests.test_missing_fragments) ... ok
test_missing_inline_bare (test_check_links.LinkCLITests.test_missing_inline_bare) ... ok
test_missing_inline_child (test_check_links.LinkCLITests.test_missing_inline_child) ... ok
test_missing_markdown (test_check_links.LinkCLITests.test_missing_markdown) ... ok
test_multiple_documents (test_check_links.LinkCLITests.test_multiple_documents) ... ok
test_ordinary_commands (test_check_links.LinkCLITests.test_ordinary_commands) ... ok
test_same_page (test_check_links.LinkCLITests.test_same_page) ... ok
test_unicode_paths (test_check_links.LinkCLITests.test_unicode_paths) ... ok

----------------------------------------------------------------------
Ran 13 tests in 1.298s

OK

```

证据：成果物/evidence/resume-syntax-check.json
命令：`python -m py_compile check_links.py test_check_links.py`
退出码：0

stdout 原文：
```text

```

stderr 原文：
```text

```

证据：成果物/evidence/resume-manual-negative.json
命令：`python check_links.py 成果物/testdata/manual-negative/first.md 成果物/testdata/manual-negative/sub/last.md`
退出码：1

stdout 原文：
```text
  MISSING  成果物/testdata/manual-negative/first.md -> node.md#section
  MISSING  成果物/testdata/manual-negative/sub/last.md -> ../python-guide.md#part
  MISSING  成果物/testdata/manual-negative/sub/last.md -> deeper/a+b.md
done, problems=3

```

stderr 原文：
```text

```

证据：成果物/evidence/resume-manual-positive.json
命令：`python check_links.py 成果物/testdata/manual-positive/first.md 成果物/testdata/manual-positive/sub/last.md`
退出码：0

stdout 原文：
```text
done, problems=0

```

stderr 原文：
```text

```

证据：成果物/evidence/resume-source-after.json
命令：`python 成果物/evidence/review_sources.py`
退出码：0

stdout 原文：
```text
HTTP block text comparison: identical (not a network test).
e1faaebb9eaeb3bafdf13cb33ab8c2e3825aafde66a7b6b37e034f4d49f44ea4 README.md
b45158b0316024c8e2c9dbe727e493d63ce1bf840f2a8f9d9bd91355ffce45c0 check_links.py
cf75bb6abbe2c3d25a03724f88d13104f2c819e020cef8224165451d396de4e0 test_check_links.py
5991438e7e1752a24c6a14d2c3e13b9e94284ff39b4c80d3bfeb55c1d27c667b 成果物/evidence/original_check_links.py
d02935b409642d0712973ec4509172c5beabaf182b03d38abcc671715713c052 成果物/testdata/cases.json
--- original_check_links.py
+++ check_links.py
@@ -11,16 +11,18 @@
 for mf in md_files:
     base = os.path.dirname(os.path.abspath(mf))
     text = open(mf, encoding='utf-8').read()
-    # 相对路径：`xxx/yyy.md` 或 [..](xxx/yyy.md)，排除 http 与含空格的
-    rels = set(re.findall(r'`((?:[\w一-鿿.-]+/)+[\w一-鿿.-]*)`', text))
-    rels |= set(re.findall(r'\]\(((?!http)[^)\s#]+)\)', text))
+    # 行内代码只识别裸 .md 或含目录的路径；Markdown 链接可省扩展名。
+    rels = {
+        r for r in re.findall(r'`([^`\s()]+)`', text)
+        if '/' in r.split('#')[0] or r.split('#')[0].endswith('.md')
+    }
+    rels |= set(re.findall(r'\]\(([^()\s]+)\)', text))
     for r in sorted(rels):
         r2 = r.split('#')[0]
-        if not r2 or r2.startswith(('--', 'python', 'npm', 'node', 'scripts/search')):
+        if not r2 or r2.startswith(('http://', 'https://')):
             continue
         p = os.path.normpath(os.path.join(base, r2))
         if not os.path.exists(p):
-            # 也试从 参考资料/ 根解析（pro 里写的是相对自己目录的路径）
             print(f"  MISSING  {mf} -> {r}")
             bad += 1
     urls = set(re.findall(r'https?://[^\s)>\]`"]+', text))
@@ -34,3 +36,4 @@
         except Exception as e:
             print(f"  HTTP ERR  {mf} -> {u}  ({str(e)[:60]})"); bad += 1
 print(f"done, problems={bad}")
+sys.exit(1 if bad else 0)


```

stderr 原文：
```text

```

证据：成果物/evidence/resume-diff-review.json
命令：`python 成果物/evidence/resume-review.py`
退出码：0

stdout 原文：
```text
Resumption source diff: only final exit expression (text comparison).
--- resume-before
+++ current
@@ -36,4 +36,4 @@
         except Exception as e:
             print(f"  HTTP ERR  {mf} -> {u}  ({str(e)[:60]})"); bad += 1
 print(f"done, problems={bad}")
-sys.exit(0)
+sys.exit(1 if bad else 0)

resume-manual-negative: expected exit 1 and summary confirmed.
resume-manual-positive: expected exit 0 and summary confirmed.
e1faaebb9eaeb3bafdf13cb33ab8c2e3825aafde66a7b6b37e034f4d49f44ea4 README.md
b45158b0316024c8e2c9dbe727e493d63ce1bf840f2a8f9d9bd91355ffce45c0 check_links.py
cf75bb6abbe2c3d25a03724f88d13104f2c819e020cef8224165451d396de4e0 test_check_links.py
d02935b409642d0712973ec4509172c5beabaf182b03d38abcc671715713c052 成果物/testdata/cases.json

```

stderr 原文：
```text

```

### 错误指纹
空。续跑基线 command_prefix_paths、extensionless_link、missing_fragments、missing_inline_bare、missing_inline_child、missing_markdown、multiple_documents、unicode_paths 的退出码断言全部恢复。进展证据：同一批 13 项由 8 失败变为 0；独立两文档缺失 3 个时 exit 1，齐全时 exit 0。
### 下一轮计划
技术工作完成，提交本次证据供用户最终验收；没有下一项业务任务。

## 收尾核验（Round 3 续跑）
- 独立对照：读了两组混合输入，确认输入相同、文件存在状态不同；重新真实运行 CLI 并核对 3 条缺失及统计、exit 1/0。未靠旧结果结案。
- diff 回看：与续跑起点逐行文本对比，仅最后退出表达式变化；测试程序与数据 SHA 未变。没有放宽/删除断言，没有 mock。
- 影响检查：项目内搜索调用处为 README 与测试；退出码契约按原需求修复。片段、路径解析、多文档、命令词排除通过原 13 项回归。HTTP 源码未改；网络功能未验证。
- 基线 → 终态：本次 13 项中 8 失败 → 0 失败；新增 1 修复轮，沿用总 Round 3/10，未触发停滞。
- 当前版本：check_links.py SHA-256 b45158b0316024c8e2c9dbe727e493d63ce1bf840f2a8f9d9bd91355ffce45c0。旧 Round 2 源码摘要及旧报告只作历史证据。
- 教训回写：CLAUDE.md，缺文件仍 exit 0 再现时必须核对真实退出码，不凭日志或旧绿灯。
- 验收逐条核销：成果物/续跑交付报告.md；实测、源码读到的、未验证范围分开表述，不把技术完成写成人已验收。
- 类型检查：本 Python 项目无 npm/type-check，语法编译 exit 0；静态类型检查未做。
- 归档：同一任务接续，根 LOOP.md 保留；新增 resume-* 文件和当前报告，历史报告、输出不覆盖。未提交代码。
