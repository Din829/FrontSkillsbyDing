"""Run a command and preserve its unmodified output and exit status."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
result = subprocess.run(command, cwd=root, capture_output=True)
destination = root / '成果物' / 'evidence'
destination.mkdir(parents=True, exist_ok=True)
record = destination / f'{label}.json'
with record.open('x', encoding='utf-8') as stream:
    json.dump({
        'command': command,
        'cwd': str(root),
        'exit_code': result.returncode,
        'stdout': result.stdout.decode('utf-8'),
        'stderr': result.stderr.decode('utf-8'),
    }, stream, ensure_ascii=False, indent=2)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
print(f'\nRecorded {record.relative_to(root)}; exit_code={result.returncode}')
sys.exit(result.returncode)
