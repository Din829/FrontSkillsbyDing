"""
核对前端skills 里 markdown 的引用是否都指向存在的东西：
  - 反引号 / 链接里的相对路径 → 文件或目录必须存在
  - http(s) 链接 → HEAD/GET 必须 200（或 3xx 跟随后 200）
用法：python check_links.py <md 文件...>
"""
import os, re, sys, urllib.request

md_files = sys.argv[1:]
bad = 0
for mf in md_files:
    base = os.path.dirname(os.path.abspath(mf))
    text = open(mf, encoding='utf-8').read()
    # 相对路径：`xxx/yyy.md` 或 [..](xxx/yyy.md)，排除 http 与含空格的
    rels = set(re.findall(r'`((?:[\w一-鿿.-]+/)+[\w一-鿿.-]*)`', text))
    rels |= set(re.findall(r'\]\(((?!http)[^)\s#]+)\)', text))
    for r in sorted(rels):
        r2 = r.split('#')[0]
        if not r2 or r2.startswith(('--', 'python', 'npm', 'node', 'scripts/search')):
            continue
        p = os.path.normpath(os.path.join(base, r2))
        if not os.path.exists(p):
            # 也试从 参考资料/ 根解析（pro 里写的是相对自己目录的路径）
            print(f"  MISSING  {mf} -> {r}")
            bad += 1
    urls = set(re.findall(r'https?://[^\s)>\]`"]+', text))
    for u in sorted(urls):
        u = u.rstrip('.,;）')
        try:
            req = urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status != 200:
                    print(f"  HTTP {resp.status}  {mf} -> {u}"); bad += 1
        except Exception as e:
            print(f"  HTTP ERR  {mf} -> {u}  ({str(e)[:60]})"); bad += 1
print(f"done, problems={bad}")
