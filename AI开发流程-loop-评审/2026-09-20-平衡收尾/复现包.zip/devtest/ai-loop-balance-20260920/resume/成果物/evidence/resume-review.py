"""Check the actual resumption diff and preserved CLI evidence."""
import difflib
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = root / '成果物/evidence'
before = (evidence / 'resume-before-check_links.py').read_text(encoding='utf-8')
after = (root / 'check_links.py').read_text(encoding='utf-8')
assert after == before.replace('sys.exit(0)', 'sys.exit(1 if bad else 0)')
print('Resumption source diff: only final exit expression (text comparison).')
print(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                  fromfile='resume-before', tofile='current')))
for label, code, summary in [('resume-manual-negative', 1, 'done, problems=3'),
                             ('resume-manual-positive', 0, 'done, problems=0')]:
    record = json.loads((evidence / f'{label}.json').read_text(encoding='utf-8'))
    assert record['exit_code'] == code
    assert record['stdout'].splitlines()[-1] == summary
    assert record['stderr'] == ''
    print(f'{label}: expected exit {code} and summary confirmed.')
for name in ['README.md', 'check_links.py', 'test_check_links.py', '成果物/testdata/cases.json']:
    print(hashlib.sha256((root / name).read_bytes()).hexdigest(), name)
