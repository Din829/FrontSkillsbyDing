"""Preserve a source comparison against the original input."""
import difflib
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parents[2]
old = (root / '成果物/evidence/original_check_links.py').read_text(encoding='utf-8')
new = (root / 'check_links.py').read_text(encoding='utf-8')
old_http = old[old.index('    urls ='):old.index('print(f"done,')]
new_http = new[new.index('    urls ='):new.index('print(f"done,')]
assert old_http == new_http
print('HTTP block text comparison: identical (not a network test).')
for name in ['README.md', 'check_links.py', 'test_check_links.py',
             '成果物/evidence/original_check_links.py', '成果物/testdata/cases.json']:
    print(hashlib.sha256((root / name).read_bytes()).hexdigest(), name)
print(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                  fromfile='original_check_links.py', tofile='check_links.py')))
