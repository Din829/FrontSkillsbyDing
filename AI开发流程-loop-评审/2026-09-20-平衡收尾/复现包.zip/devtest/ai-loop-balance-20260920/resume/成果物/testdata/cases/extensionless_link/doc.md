[exists](LICENSE) [missing](NOTICE)
