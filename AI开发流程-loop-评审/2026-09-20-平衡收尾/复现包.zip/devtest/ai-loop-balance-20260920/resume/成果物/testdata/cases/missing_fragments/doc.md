[gone](lost.md#part) `other.md#part` `sub/absent.txt#part`
