"""Independent calibration reference, limited to the local fixture grammar."""
from pathlib import Path
import re
import sys

missing = 0
for argument in sys.argv[1:]:
    source = Path(argument)
    content = source.read_text(encoding='utf-8')
    references = set()
    for token in re.finditer(r'\]\(([^\s()]+)\)|`([^`\s()]+)`', content):
        link, code = token.groups()
        reference = link or code
        filename = reference.partition('#')[0]
        if filename and (link is not None or '/' in filename or filename.endswith('.md')):
            references.add(reference)
    for reference in sorted(references):
        filename = reference.partition('#')[0]
        if not (source.parent / filename).exists():
            print(f'  MISSING  {argument} -> {reference}')
            missing += 1
print(f'done, problems={missing}')
sys.exit(1 if missing else 0)
