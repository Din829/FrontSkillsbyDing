Existing target; fragment content deliberately differs.
