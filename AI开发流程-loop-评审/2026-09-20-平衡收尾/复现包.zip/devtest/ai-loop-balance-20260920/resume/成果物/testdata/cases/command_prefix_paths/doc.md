`python.md` [npm](npm.md) [node](node.md) `scripts/search-guide.md`
