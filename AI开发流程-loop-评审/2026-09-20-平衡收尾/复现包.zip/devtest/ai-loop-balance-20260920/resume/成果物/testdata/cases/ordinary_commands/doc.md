`python` `npm test` `node` `--help` `python run.py`
