import json
from pathlib import Path
import sys

expected = {"B": 1005, "C": -29}
task = sys.argv[1]
actual = json.loads((Path(__file__).resolve().parent / "output" / (task + ".json")).read_text())
assert actual == {"id": task, "cents": expected[task]}, actual
print(f"PASS {task}: cents={actual['cents']}")
