import json
from pathlib import Path
import sys
from decimal import Decimal

root = Path(__file__).resolve().parent
item = next(r for r in json.loads((root / "items.json").read_text()) if r["id"] == sys.argv[1])
if item["unit"] != "USD":
    print(f'BLOCKED {item["id"]}: unit {item["unit"]} has no confirmed definition')
    sys.exit(3)
output = {"id": item["id"], "cents": int(Decimal(item["amount"]) * 100)}
(root / "output").mkdir(exist_ok=True)
(root / "output" / (item["id"] + ".json")).write_text(json.dumps(output), encoding="utf-8")
print(json.dumps(output))
