# 目标循环账本

## 目标
任务 A：将 LEGACY 金额转换为分。仅在单位含义由人确认后执行。

## 状态
⛔ A blocked，B/C 尚未开始；用户离线，未知定义不能猜测。

## 基线
命令：python convert_one.py A
退出码：3
原始 stdout：
BLOCKED A: unit LEGACY has no confirmed definition

## 下一步
待问 Q-A：LEGACY 的单位及换算规则是什么？A 不影响 USD 项 B/C。
