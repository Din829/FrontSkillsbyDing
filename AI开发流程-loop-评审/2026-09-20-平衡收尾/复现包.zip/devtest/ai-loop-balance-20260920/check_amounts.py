"""Independent value/exception oracle; input answers fixed before implementation."""
import importlib.util
import json
from pathlib import Path
import sys
import hashlib

source, destination = (Path(p).resolve() for p in sys.argv[1:])
cases = json.loads((Path(__file__).parent / "amount_cases.json").read_text(encoding="utf-8"))
spec = importlib.util.spec_from_file_location("candidate_amounts", source)
module = importlib.util.module_from_spec(spec)
if not source.exists():
    destination.write_text(json.dumps({"state": "business_module_missing", "path": str(source)}), encoding="utf-8")
    print("BUSINESS MODULE MISSING; this is not a passing test")
    sys.exit(2)
spec.loader.exec_module(module)
results = []
for value, expected in cases["valid"]:
    try:
        actual = module.parse_cents(value)
        passed = type(actual) is int and actual == expected
        observed = {"value": actual, "type": type(actual).__name__}
    except Exception as exc:
        passed, observed = False, {"exception": type(exc).__name__, "message": str(exc)}
    results.append({"input": value, "expected": expected, "actual": observed, "passed": passed})
for value in cases["invalid"]:
    try:
        actual = module.parse_cents(value)
        passed, observed = False, {"value": actual}
    except Exception as exc:
        passed, observed = type(exc) is ValueError, {"exception": type(exc).__name__, "message": str(exc)}
    results.append({"input": value, "expected": "ValueError", "actual": observed, "passed": passed})
output = {"source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "results": results,
          "matched": sum(r["passed"] for r in results), "total": len(results)}
destination.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"matched": output["matched"], "total": output["total"]}))
sys.exit(0 if all(r["passed"] for r in results) else 1)
