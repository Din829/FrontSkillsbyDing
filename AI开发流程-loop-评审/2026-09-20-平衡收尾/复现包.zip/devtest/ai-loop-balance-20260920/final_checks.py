"""Root-run verification; calibration failures remain explicitly non-success outcomes."""
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
WS = BASE.parents[1]
records = []


def run(name, command, cwd, expected=0):
    cp = subprocess.run([str(x) for x in command], cwd=cwd, capture_output=True, text=True,
                        encoding="utf-8", env={**os.environ, "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    item = {"name": name, "cwd": str(cwd), "argv": [str(x) for x in command],
            "expected_exit": expected, "exit_code": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr}
    records.append(item)
    (BASE / "final-commands.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    assert (cp.returncode != 0 if expected == "nonzero" else cp.returncode == expected), item
    print(name, "exit", cp.returncode, flush=True)
    return cp


for task in ["resume", "greenfield"]:
    cp = run(task + "-unit-tests", [sys.executable, "-m", "unittest", "discover", "-v"], BASE / task)
    assert "Ran " in cp.stderr and "Ran 0 tests" not in cp.stderr
run("amounts-strict-types", [sys.executable, "-m", "mypy", "--strict", "amounts.py"], BASE / "greenfield")

control = BASE / "controls"
control.mkdir(exist_ok=False)
(control / "float_amounts.py").write_text("def parse_cents(text: str) -> int:\n    return int(float(text.strip()) * 100)\n", encoding="utf-8")
run("float-mutant-rejected", [sys.executable, BASE / "check_amounts.py", control / "float_amounts.py", BASE / "amounts-float-mutant.json"], BASE, "nonzero")
float_result = json.loads((BASE / "amounts-float-mutant.json").read_text())
assert any(r["input"] == "0.29" and r["actual"].get("value") == 28 and not r["passed"] for r in float_result["results"])
assert any(r["input"].startswith("999999") and not r["passed"] for r in float_result["results"])
(control / "wrong_type.py").write_text('def parse_cents(text: str) -> int:\n    return "wrong"\n', encoding="utf-8")
cp = run("type-checker-negative", [sys.executable, "-m", "mypy", "--strict", "--no-incremental", "wrong_type.py"], control, "nonzero")
assert "Incompatible return value type" in cp.stdout

# Requested npm check remains scoped to the TypeScript experiment, not mislabeled Python syntax checks.
npm = Path(os.environ["ProgramFiles"]) / "nodejs/npm.cmd"
run("npm-type-check", [npm, "run", "type-check"], WS / "devtest/ai-loop-review-20260920")
run("git-diff-check", ["git", "diff", "--check", "--", "AI开发流程-loop"], WS / "参考设计思想")
print("ROOT_CHECKS_COMPLETED")
