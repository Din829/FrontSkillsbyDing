def parse_cents(text: str) -> int:
    return int(float(text.strip()) * 100)
