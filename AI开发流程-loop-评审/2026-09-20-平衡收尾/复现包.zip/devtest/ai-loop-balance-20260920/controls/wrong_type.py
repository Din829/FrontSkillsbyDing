def parse_cents(text: str) -> int:
    return "wrong"
